# M5StickC + Marauder: Visualizador Web de Escaneo WiFi

Este proyecto permite mostrar los datos del escaneo WiFi desde el M5StickC ejecutando Marauder en una vista web fácil de leer.

## Requisitos

- Python 3.x
- PuTTY configurado para guardar el log del escaneo WiFi en: `logs/wifi_scan_marauder.log`
- Flask (`pip install flask`)

## Instrucciones

1. Conecta tu M5StickC con el firmware Marauder.
2. Abre PuTTY en modo serial y guarda el log en `logs/wifi_scan_marauder.log`.
3. Ejecuta el visor web:

```bash
python wifi_web.py
```

4. Abre el navegador en [http://127.0.0.1:5000](http://127.0.0.1:5000)

¡Listo! Verás en tiempo real los puntos de acceso WiFi detectados.

## Vista previa

```
Canal | RSSI | BSSID              | ESSID
------|------|--------------------|---------------
   6  | -85  | 4c:ab:fb:33:54:b7  | MOVISTAR_9C29
   7  | -73  | d4:f8:29:a7:17:b0  | MiFibra-17B0
```

Puedes editar el CSS en el archivo `wifi_web.py` para cambiar los colores y fuente.
